package com.example.travel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
